#!/usr/bin/env python3
"""Backward-compatible GUI wrapper."""

from turmo.gui import main


if __name__ == "__main__":
    raise SystemExit(main())
