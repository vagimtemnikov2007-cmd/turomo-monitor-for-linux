#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
printf '\nOK. Run GUI: ./run_gui.sh\nCLI still works: python turmo_lite.py --help\n'
